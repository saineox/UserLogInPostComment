//package com.example.demo.services;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.model.User;
//
//
//@Service
//public interface UserIServices 
//{
//	
//	
//	
//	
//	public Optional<User> findUser(Integer user_id);
//	public Optional<User> findUserByName(String user_name);
//	
//}
